const NewUser = require('../models/registration.model');

//Simple version, without validation or sanitation
exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};
exports.User_create = function (req, res,next) {
    let newUser = new NewUser(
        {
            firstname: req.body.firstname,
            email: req.body.email,
            country: req.body.country,
            lastname: req.body.lastname,
            age: req.body.age,
            gender: req.body.gender,
            password: req.body.password

        }
    );

    newUser.save(function (err) {
        if (err) {
            return next(err);
        }
        return res.send({res: "Posted successfully"})
    })

   
    
};

exports.Fetch_user = function (req, res) {
    NewUser.find({email:req.query.email,password:req.query.password}, function (err, NewUser) {
        if (err) return next(err);
        res.send(NewUser);
    },
    )
};

// exports.product_details = function (req, res) {
//     Product.find({}, function (err, product) {
//         if (err) return next(err);
//         res.send(product);
//     })
// };